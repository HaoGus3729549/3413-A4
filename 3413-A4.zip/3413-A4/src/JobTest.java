import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;

public class JobTest {

    @Before
    public void deletePreviousTestFile(){
        //delete previous test file
        File file = new File("job_output.txt");
        file.delete();
    }

    @Test
    public void testAddJob() {
        // Test Case 1: Check the function with an INCORRECT Job Id(Number)
        System.out.println("Test Case 1");
        Job job1 = new Job();
        job1.setJobNumber("1234MMM_");
        job1.setJobTitle("Software Engineer");
        job1.setJobPosterName("Company A");
        job1.setJobPosterAddress("Melbourne, Victoria, Australia");
        job1.setJobPosterDate("2023-02-05");
        job1.setJobExperienceLevel("Senior");
        job1.setJobType("Full-time");
        job1.setJobRequiredSkills(new String[]{"Java", "SQL"});
        job1.setJobSalary(120000);
        job1.setJobDescription("Leading the development of large-scale websites for the company");
        boolean isAdded1 = job1.addJob(job1);
        Assert.assertFalse(isAdded1);
        // Set other job properties...
        job1.setJobNumber("12345MMMM");
        isAdded1 = job1.addJob(job1);
        Assert.assertFalse(isAdded1);

        // Test Case 2: Verify the function with an INCORRECT Date
        System.out.println("Test Case 2");
        Job job2 = new Job();
        job2.setJobNumber("22222ASA_");
        job2.setJobTitle("Data Analyst");
        job2.setJobPosterName("Company B");
        job2.setJobPosterAddress("ShenZhen,GuangDong,China");
        job2.setJobPosterDate("2023/02/05");
        job2.setJobExperienceLevel("Senior");
        job2.setJobType("Full-time");
        job2.setJobRequiredSkills(new String[]{"Java", "SQL"});
        job2.setJobSalary(200000);
        job2.setJobDescription("Reviews data to identify key insights into a business's customers and ways the data can be used to solve problems....");
        boolean isAdded2 = job2.addJob(job2);
        Assert.assertFalse(isAdded2);
        // Set other job properties...
        job2.setJobPosterDate("2023-50-90");
        isAdded2 = job2.addJob(job2);
        Assert.assertFalse(isAdded2);

        // Test Case 3: Verify the function with an CORRECT Address
        System.out.println("Test Case 3");
        Job job3 = new Job();
        job3.setJobNumber("33333ASA_");
        job3.setJobTitle("Data Analyst");
        job3.setJobPosterName("Company B");
        job3.setJobPosterAddress("Melbourne, Victoria, Australia");
        job3.setJobPosterDate("2023-02-05");
        job3.setJobExperienceLevel("Senior");
        job3.setJobType("Full-time");
        job3.setJobRequiredSkills(new String[]{"Java", "SQL"});
        job3.setJobSalary(200000);
        job3.setJobDescription("Reviews data to identify key insights into a business's customers and ways the data can be used to solve problems....");
        boolean isAdded3 = job3.addJob(job3);
        Assert.assertTrue(isAdded3);
        // Set other job properties...
        job3.setJobPosterAddress("ShenZhen,GuangDong,China");
        isAdded3 = job3.addJob(job3);
        Assert.assertTrue(isAdded3);

        // Test Case 4: Verify the function with an CORRECT Salary
        System.out.println("Test Case 4");
        Job job4 = new Job();
        job4.setJobNumber("44444JOB$");
        job4.setJobTitle("Data Analyst");
        job4.setJobPosterName("Company C");
        job4.setJobPosterAddress("ShenZhen,GuangDong,China");
        job4.setJobPosterDate("2023-02-05");
        job4.setJobExperienceLevel("Senior");
        job4.setJobType("Full-time");
        job4.setJobRequiredSkills(new String[]{"Java", "SQL"});
        job4.setJobSalary(200000);
        job4.setJobDescription("Reviews data to identify key insights into a business's customers and ways the data can be used to solve problems....");
        boolean isAdded4 = job4.addJob(job4);
        Assert.assertTrue(isAdded4);
        // Set other job properties...
        job4.setJobExperienceLevel("Junior");
        job4.setJobSalary(50000);
        isAdded4 = job4.addJob(job4);
        Assert.assertTrue(isAdded4);

        // Test Case 5: Verify the function with an INCORRECT Type and Executive levels
        System.out.println("Test Case 5");
        Job job5 = new Job();
        job5.setJobNumber("55555JOB#");
        job5.setJobTitle("Data Analyst");
        job5.setJobPosterName("Company C");
        job5.setJobPosterAddress("Melbourne, Victoria, Australia");
        job5.setJobPosterDate("2023-02-05");
        job5.setJobExperienceLevel("Senior");
        job5.setJobType("Part-time");
        job5.setJobRequiredSkills(new String[]{"Java", "SQL"});
        job5.setJobSalary(200000);
        job5.setJobDescription("Reviews data to identify key insights into a business's customers and ways the data can be used to solve problems....");
        boolean isAdded5 = job5.addJob(job5);
        Assert.assertFalse(isAdded5);
        // Set other job properties...
        job5.setJobExperienceLevel("Executive");
        job5.setJobType("Part-time");
        isAdded5 = job5.addJob(job5);
        Assert.assertFalse(isAdded5);

        // Test Case 6: Verify the function with an INCORRECT Skills
        System.out.println("Test Case 6");
        Job job6 = new Job();
        job6.setJobNumber("66666JOB!");
        job6.setJobTitle("Data Analyst");
        job6.setJobPosterName("Company C");
        job6.setJobPosterAddress("Melbourne, Victoria, Australia");
        job6.setJobPosterDate("2023-02-05");
        job6.setJobExperienceLevel("Junior");
        job6.setJobType("Part-time");
        job6.setJobRequiredSkills(new String[]{"Java", "SQL","Excel","Word"});
        job6.setJobSalary(50000);
        job6.setJobDescription("Reviews data to identify key insights into a business's customers and ways the data can be used to solve problems....");
        boolean isAdded6 = job6.addJob(job6);
        Assert.assertFalse(isAdded6);
        // Set other job properties...
        job6.setJobRequiredSkills(new String[]{"Java", "Writing Unit Tests"});
        isAdded6 = job6.addJob(job6);
        Assert.assertFalse(isAdded6);

    }



    @Test
    public void testUpdateJob() {
        //Add 2 valid job
        Job job1 = new Job();
        job1.setJobNumber("12345AAA_");
        job1.setJobTitle("Software Engineer");
        job1.setJobPosterName("Company A");
        job1.setJobPosterAddress("Melbourne, Victoria, Australia");
        job1.setJobPosterDate("2023-05-27");
        job1.setJobExperienceLevel("Senior");
        job1.setJobType("Full-time");
        job1.setJobRequiredSkills(new String[]{"Java", "SQL"});
        job1.setJobSalary(120000);
        job1.setJobDescription("Leading the development of large-scale websites for the company");
        job1.addJob(job1);

        Job job2 = new Job();
        job2.setJobNumber("12345BBB_");
        job2.setJobTitle("Data Analyst");
        job2.setJobPosterName("Company B");
        job2.setJobPosterAddress("ShenZhen,GuangDong,China");
        job2.setJobPosterDate("2023-02-05");
        job2.setJobExperienceLevel("Junior");
        job2.setJobType("Part-time");
        job2.setJobRequiredSkills(new String[]{"Java", "SQL"});
        job2.setJobSalary(60000);
        job2.setJobDescription("Reviews data to identify key insights into a business's customers and ways the data can be used to solve problems....");
        job2.addJob(job2);

        // Test Case 1: Update a non-existent job
        System.out.println("Test Case 1");
        job1.setJobNumber("12345CCC_");
        Job nonExistentJob = job1;
        boolean isUpdated1 = nonExistentJob.updateJob(nonExistentJob);
        Assert.assertFalse(isUpdated1);
        Job updatedJob1 = Job.recoverJobFromFile("12345AAA_");
        // Set other updated job properties...
        updatedJob1.setJobNumber("12345CCC_");
        updatedJob1.setJobPosterName("Company B");
        isUpdated1 = updatedJob1.updateJob(updatedJob1);
        Assert.assertFalse(isUpdated1);

        // Test Case 2: Update job to be invalided (Address and JobPosterDate)
        System.out.println("Test Case 2");
        Job updatedJob2 = Job.recoverJobFromFile("12345AAA_");
        updatedJob2.setJobPosterName("Company B");
        updatedJob2.setJobPosterAddress("AAA");
        boolean isUpdated2 = updatedJob2.updateJob(updatedJob2);
        Assert.assertFalse(isUpdated2);
        updatedJob2 = Job.recoverJobFromFile("12345AAA_");
        // Set other updated job properties...
        updatedJob2.setJobPosterDate("9999-99-99");
        isUpdated2 = updatedJob2.updateJob(updatedJob2);
        Assert.assertFalse(isUpdated2);

        // Test Case 3: Update job about salary
        System.out.println("Test Case 3");
        Job updatedJob3 = Job.recoverJobFromFile("12345AAA_");
        updatedJob3.setJobSalary(150000);
        boolean isUpdated3 = updatedJob3.updateJob(updatedJob3);
        Assert.assertTrue(isUpdated3);
        updatedJob3 = Job.recoverJobFromFile("12345BBB_");
        // Set other updated job properties...
        updatedJob3.setJobSalary(65000);
        isUpdated3 = updatedJob3.updateJob(updatedJob3);
        Assert.assertTrue(isUpdated3);

        // Test Case 4: Update job about type
        System.out.println("Test Case 4");
        Job updatedJob4 = Job.recoverJobFromFile("12345AAA_");
        updatedJob4.setJobType("Internship");
        boolean isUpdated4 = updatedJob4.updateJob(updatedJob4);
        Assert.assertTrue(isUpdated4);
        updatedJob4 = Job.recoverJobFromFile("12345BBB_");
        // Set other updated job properties...
        updatedJob4.setJobType("Full-time");
        isUpdated4 = updatedJob4.updateJob(updatedJob4);
        Assert.assertTrue(isUpdated4);

        // Test Case 5: Update job about type and exprience
        System.out.println("Test Case 5");
        Job updatedJob5 = Job.recoverJobFromFile("12345AAA_");
        updatedJob5.setJobType("adsfasdfsdf");
        boolean isUpdated5 = updatedJob5.updateJob(updatedJob5);
        Assert.assertFalse(isUpdated5);
        updatedJob5 = Job.recoverJobFromFile("12345BBB_");
        // Set other updated job properties...
        updatedJob5.setJobExperienceLevel("sadfasfdasd");
        isUpdated5 = updatedJob5.updateJob(updatedJob5);
        Assert.assertFalse(isUpdated5);

        // Test Case 6: Update nothing change and just null
        System.out.println("Test Case 6");
        Job updatedJob6 = Job.recoverJobFromFile("12345AAA_");
        boolean isUpdated6 = updatedJob6.updateJob(updatedJob6);
        Assert.assertTrue(isUpdated6);
        isUpdated6 = updatedJob6.updateJob(null);
        Assert.assertFalse(isUpdated6);
    }
}
