import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Job {

    private String jobNumber;
    private String jobTitle;
    private String jobPosterName;
    private String jobPosterAddress;
    private String jobPosterDate;
    private String jobExperienceLevel;
    private String jobType;
    private String[] jobRequiredSkills;
    private double jobSalary;
    private String jobDescription;

    private static String filePath = "job_output.txt";

    public String getJobNumber() {
        return jobNumber;
    }

    public void setJobNumber(String jobNumber) {
        this.jobNumber = jobNumber;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getJobPosterName() {
        return jobPosterName;
    }

    public void setJobPosterName(String jobPosterName) {
        this.jobPosterName = jobPosterName;
    }

    public String getJobPosterAddress() {
        return jobPosterAddress;
    }

    public void setJobPosterAddress(String jobPosterAddress) {
        this.jobPosterAddress = jobPosterAddress;
    }

    public String getJobPosterDate() {
        return jobPosterDate;
    }

    public void setJobPosterDate(String jobPosterDate) {
        this.jobPosterDate = jobPosterDate;
    }

    public String getJobExperienceLevel() {
        return jobExperienceLevel;
    }

    public void setJobExperienceLevel(String jobExperienceLevel) {
        this.jobExperienceLevel = jobExperienceLevel;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String[] getJobRequiredSkills() {
        return jobRequiredSkills;
    }

    public void setJobRequiredSkills(String[] jobRequiredSkills) {
        this.jobRequiredSkills = jobRequiredSkills;
    }

    public double getJobSalary() {
        return jobSalary;
    }

    public void setJobSalary(double jobSalary) {
        this.jobSalary = jobSalary;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    //
    public Job(String jobNumber, String jobTitle, String jobPosterName, String jobPosterAddress, String jobPosterDate,
               String jobExperienceLevel, String jobType, String[] jobRequiredSkills, double jobSalary, String jobDescription) {
        this.jobNumber = jobNumber;
        this.jobTitle = jobTitle;
        this.jobPosterName = jobPosterName;
        this.jobPosterAddress = jobPosterAddress;
        this.jobPosterDate = jobPosterDate;
        this.jobExperienceLevel = jobExperienceLevel;
        this.jobType = jobType;
        this.jobRequiredSkills = jobRequiredSkills;
        this.jobSalary = jobSalary;
        this.jobDescription = jobDescription;
    }

    public Job() {

    }

    //add job to txt,but validate first
    public boolean addJob(Job job){
        if (job==null){
            System.out.println("Add job fail! Param is null");
            return false;
        }
        //validate job,if it doesn't meet the all conditions,write nothing,return false
        if (!validateJob(job)){
            System.out.println("Add job fail! Invalid job.");
            return false;
        }
        wirteNewJobToTxt(job);
        return true;
    }

    //update job ,but validate first
    public boolean updateJob(Job updateJob){
        if (updateJob==null){
            System.out.println("Update job fail! Param is null");
            return false;
        }
        //recover job from txt file by job number
        Job recoveredJob = recoverJobFromFile(updateJob.getJobNumber());
        if (recoveredJob==null){
            System.out.println("Update job fail! Job with JobNumber " + jobNumber + " not found in the file.");
            return false;
        }
        //validate job,if it doesn't meet the all conditions,update nothing,return false
        if (!validateJob(updateJob)){
            System.out.println("Update job fail! Invalid job.");
            return false;
        }
        //validate job type
        if (recoveredJob.getJobType().equals("Full-time")) {
            if(updateJob.getJobType().equals("Part-time")||updateJob.getJobType().equals("Volunteer")){
                System.out.println("Full-time jobs can not be changed to Part-time or Volunteer jobs");
                return false;
            }
        }
        //validate salary
        double currentSalary = recoveredJob.getJobSalary();
        double newSalary = updateJob.getJobSalary();
        if (currentSalary!=newSalary){
            if (recoveredJob.getJobExperienceLevel().equals("Junior")) {
                if (newSalary/currentSalary>1.1){
                    System.out.println("The salary of Junior jobs should not be increased by more than 10%");
                    return false;
                }
            } else {
                if (newSalary/currentSalary<1.2||newSalary/currentSalary>1.4){
                    System.out.println("The salary of all jobs except Junior jobs can be increased by between 20% and 40%.");
                    return false;
                }
            }
        }
        //all conditions are verified,update job to txt file
        updateJobToFile(updateJob);
        return true;
    }

    //all conditions in addJob
    public boolean validateJob(Job job) {
        return validateJobExperienceLevel(job.getJobExperienceLevel())
                &&validateJobType(job.getJobType())
                &&validateJobId(job.getJobNumber())
                &&validateJobDate(job.getJobPosterDate())
                &&validateJobAddress(job.getJobPosterAddress())
                &&validateSalary(job.getJobExperienceLevel(),job.getJobSalary())
                &&validateTypeAndLevel(job.getJobType(),job.getJobExperienceLevel())
                &&validateRequiredSkills(job.getJobRequiredSkills());
    }

    //Note 1
    public boolean validateJobExperienceLevel(String jobExperienceLevel) {
        if (!(jobExperienceLevel.equals("Junior")
                ||jobExperienceLevel.equals("Medium")
                ||jobExperienceLevel.equals("Senior")
                ||jobExperienceLevel.equals("Executive"))){
            System.out.println("There are four job experience levels: Junior, Medium, Senior, Executive");
            return false;
        }
        return true;
    }

    //Note 2
    public boolean validateJobType(String jobType) {
        if (!(jobType.equals("Full-time")
                ||jobType.equals("Part-time")
                ||jobType.equals("Internship")
                ||jobType.equals("Volunteer"))){
            System.out.println("There are four job types: Full-time, Part-time, Internship, Volunteer");
            return false;
        }
        return true;
    }

    //Condition 1
    public boolean validateJobId(String jobId) {
        if (jobId.length() != 9) {
            System.out.println("Job ID should be exactly 9 characters long");
            return false;
        }

        for (int i = 0; i < 5; i++) {
            if (!Character.isDigit(jobId.charAt(i))) {
                System.out.println("The first five characters should be numbers between 1 and 5");
                return false;
            }
        }

        for (int i = 5; i < 8; i++) {
            if (!Character.isUpperCase(jobId.charAt(i))) {
                System.out.println("The characters 6th to 8th should be upper case letters (A-Z) ");
                return false;
            }
        }

        char lastChar = jobId.charAt(8);
        if (!isSpecialCharacter(lastChar)) {
            System.out.println("The last character should be a special character");
            return false;
        }

        return true;
    }

    //some common special character
    private boolean isSpecialCharacter(char c) {
        String specialCharacters = "!@#$%^&*()_-+=~";
        return specialCharacters.contains(String.valueOf(c));
    }

    //Condition 2  not just format,also includes the value range of year, month and day
    public boolean validateJobDate(String date) {
        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
            System.out.println("The date that a job is posted should follow the following format: YYYY-MM-DD");
            return false;
        }

        int year = Integer.parseInt(date.substring(0, 4));
        if (year < 1000 || year > 9999) {
            System.out.println("The date of year is illegal");
            return false;
        }

        int month = Integer.parseInt(date.substring(5, 7));
        if (month < 1 || month > 12) {
            System.out.println("The date of month is illegal");
            return false;
        }

        int day = Integer.parseInt(date.substring(8, 10));
        if (day < 1 || day > 31) {
            System.out.println("The date of day is illegal");
            return false;
        }

        return true;
    }

    //Condition 3
    public boolean validateJobAddress(String address) {
        String[] parts = address.split(",");
        //must be three parameters separated by commas
        if (parts.length != 3) {
            System.out.println("The address of the job poster (company) should follow the following format: City, State, Country. Example: Melbourne, Victoria, Australia.");
            return false;
        }

        String city = parts[0].trim();
        String state = parts[1].trim();
        String country = parts[2].trim();
        //neither can be empty
        if (city.isEmpty() || state.isEmpty() || country.isEmpty()) {
            System.out.println("The address of the job poster (company) should follow the following format: City, State, Country. Example: Melbourne, Victoria, Australia.");
            return false;
        }

        return true;
    }

    //Condition 4
    public boolean validateSalary(String jobExperienceLevel,double jobSalary) {
        if (jobExperienceLevel.equals("Senior") || jobExperienceLevel.equals("Executive")) {
            if (jobSalary < 100000){
                System.out.println("The salary for Senior and Executive jobs should not be less than 100000");
                return false;
            }
        } else if (jobExperienceLevel.equals("Junior")) {
            if (jobSalary < 40000 && jobSalary > 70000){
                System.out.println("The salary for Senior and Executive jobs should not be less than 100000");
                return false;
            }
        }
        return true;
    }

    //Condition 5
    public boolean validateTypeAndLevel(String jobType,String jobExperienceLevel) {
        if (jobType.equals("Part-time") && (jobExperienceLevel.equals("Senior") || jobExperienceLevel.equals("Executive"))) {
            System.out.println("Part-time jobs cannot be at Senior or Executive levels");
            return false;
        }
        return true;
    }

    //Condition 6
    public boolean validateRequiredSkills(String[] jobRequiredSkills) {
        int numSkills = jobRequiredSkills.length;
        //at least one skill or a maximum of three skills
        if (numSkills < 1 || numSkills > 3) {
            System.out.println("A job can require at least one skill or a maximum of three skills");
            return false;
        }

        //each skill should have a maximum of two words
        for (String skill : jobRequiredSkills) {
            String[] words = skill.split("\\s+");
            if (words.length > 2) {
                System.out.println("Each skill should have a maximum of two words");
                return false;
            }
        }
        return true;
    }


    //wirte job instance string to txt file
    public static void wirteNewJobToTxt(Job job){
        try (FileWriter writer = new FileWriter(filePath,true)) {
            writer.write(getJobDetailsString(job));
            System.out.println("Job details written to file: " + filePath);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }

    //serialize the job instance into a string
    //one line per field
    public static String getJobDetailsString(Job job) {
        StringBuilder jobDetails = new StringBuilder();
        jobDetails.append("Job Number: ").append(job.getJobNumber()).append("\n");
        jobDetails.append("Job Title: ").append(job.getJobTitle()).append("\n");
        jobDetails.append("Job Poster Name: ").append(job.getJobPosterName()).append("\n");
        jobDetails.append("Job Poster Address: ").append(job.getJobPosterAddress()).append("\n");
        jobDetails.append("Job Poster Date: ").append(job.getJobPosterDate()).append("\n");
        jobDetails.append("Job Experience Level: ").append(job.getJobExperienceLevel()).append("\n");
        jobDetails.append("Job Type: ").append(job.getJobType()).append("\n");
        jobDetails.append("Job Required Skills: ").append(String.join(", ", job.getJobRequiredSkills())).append("\n");
        jobDetails.append("Job Salary: ").append(job.getJobSalary()).append("\n");
        //one line between instance and instance,so add an another \n
        jobDetails.append("Job Description: ").append(job.getJobDescription()).append("\n").append("\n");
        return jobDetails.toString();
    }

    //update specified instance to file
    public static void updateJobToFile(Job updatedJob) {
        // read the original text file content and update the line corresponding to the specified JobNumber
        List<String> fileContent = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean found=false;
            boolean match=false;
            int index=0;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(": ");
                if (parts.length == 2 && parts[0].trim().equals("Job Number") && parts[1].trim().equals(updatedJob.getJobNumber())) {
                    found=true;
                    match=true;
                    // matches the JobNumber row to be updated, replacing it with the new property value
                    fileContent.add("Job Number: " + updatedJob.getJobNumber());
                    fileContent.add("Job Title: " + updatedJob.getJobTitle());
                    fileContent.add("Job Poster Name: " + updatedJob.getJobPosterName());
                    fileContent.add("Job Poster Address: " + updatedJob.getJobPosterAddress());
                    fileContent.add("Job Poster Date: " + updatedJob.getJobPosterDate());
                    fileContent.add("Job Experience Level: " + updatedJob.getJobExperienceLevel());
                    fileContent.add("Job Type: " + updatedJob.getJobType());
                    fileContent.add("Job Required Skills: " + String.join(", ", updatedJob.getJobRequiredSkills()));
                    fileContent.add("Job Salary: " + updatedJob.getJobSalary());
                    fileContent.add("Job Description: " + updatedJob.getJobDescription());
                } else if(match&&index<9){
                    //job instance has 10 properties,in order to avoid duplication of writing,ignore them
                    index++;
                }else {
                    // leave the original line content unchanged
                    fileContent.add(line);
                }
            }
            if (!found){
                System.out.println("Job with JobNumber " + updatedJob.getJobNumber() + " not found in the file.");
                return ;
            }

            // write the updated row data back to the text file
            try (FileWriter writer = new FileWriter(filePath)) {
                for (String content : fileContent) {
                    writer.write(content + "\n");
                }
            }

            System.out.println("Job updated successfully in the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the job: " + e.getMessage());
        }
    }

    //recover job from txt file by job number
    public static Job recoverJobFromFile(String jobNumber) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            Job recoveredJob = null;
            int index = 0;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(": ");
                if (parts.length == 2 && parts[0].trim().equals("Job Number") && parts[1].trim().equals(jobNumber)) {
                    recoveredJob = new Job();
                    recoveredJob.setJobNumber(jobNumber);
                    index++;
                } else if (recoveredJob != null && !line.isEmpty()) {
                    parts = line.split(": ");
                    if (parts.length == 2) {
                        String attributeName = parts[0].trim();
                        String attributeValue = parts[1].trim();
                        index++;
                        //job instance has 10 properties,break when find all
                        if (index>10){
                            break;
                        }
                        switch (attributeName) {
                            case "Job Title":
                                recoveredJob.setJobTitle(attributeValue);
                                break;
                            case "Job Poster Name":
                                recoveredJob.setJobPosterName(attributeValue);
                                break;
                            case "Job Poster Address":
                                recoveredJob.setJobPosterAddress(attributeValue);
                                break;
                            case "Job Poster Date":
                                recoveredJob.setJobPosterDate(attributeValue);
                                break;
                            case "Job Experience Level":
                                recoveredJob.setJobExperienceLevel(attributeValue);
                                break;
                            case "Job Type":
                                recoveredJob.setJobType(attributeValue);
                                break;
                            case "Job Required Skills":
                                recoveredJob.setJobRequiredSkills(attributeValue.split(", "));
                                break;
                            case "Job Salary":
                                recoveredJob.setJobSalary(Double.parseDouble(attributeValue));
                                break;
                            case "Job Description":
                                recoveredJob.setJobDescription(attributeValue);
                                break;
                        }
                    }
                }
            }

            return recoveredJob;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }


    public static void main(String[] args) {
//        String [] array={"AA","AA","AA"};
//        Job job = new Job("1","A","B","C","D","E","F",array, 12,"G");
    }
}
